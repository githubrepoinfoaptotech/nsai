# config.py
import os

class Config:
    SQLALCHEMY_DATABASE_URI = 'mysql+mysqlconnector://nsai_user:RSj;KI4=6iR}@localhost/nsai'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
